#include"ALL.h"

int main()
{
	srand((unsigned int)time(NULL));
	Graph** node;
	int ap[4][4] = { {0,1,0,1},{1,0,0,1},{1,0,0,0},{1,1,1,0} };
	char ch_ary[6] = { 0 };
	int cnt_ary[4] = { 0 };
	int row, col;
	int size = 4;

	

	Print_Route_info_FIXED(ap);
	puts("");

	node = Make_Node_FIXED(ap);
	Input_Route_FIXED(node, ap);


	Visit_all(node[0], ch_ary, 0);
	puts("");
	Visit_all(node[1], ch_ary, 0);
	puts("");
	Visit_all(node[2], ch_ary, 0);
	puts("");
	Visit_all(node[3], ch_ary, 0);


}
#ifdef TEST
for (row = 0; row < size; row++)
{
	printf("%c:", node[row]->ch);
	for (col = 0; col < size; col++)
	{
		if (node[row]->link[col])
			printf("%c ", node[row]->link[col]->ch);
	}
	puts("");
}



int row, col;
int size = _msize(ap) / sizeof(int*);
//0:A, 1:B, ....
for (row = 0; row < size; row++)
{
	printf("%c:", node[row]->ch);
	for (col = 0; col < size; col++)
	{
		if (node[row]->link[col])
			printf("%c ", node[row]->link[col]->ch);
		}
	puts("");
	}

while (1)
{
	ap = Make_Route();
	Print_Route_info(ap);
	system("pause");
	}

#endif

#ifdef BASIC_SET

srand((unsigned int)time(NULL));
Graph** node;
int** ap = Make_Route();
char ch_ary[5] = { 0 };



Print_Route_info(ap);
puts("");
node = Make_Node(ap);
Input_Route(node, ap);

Visit_every_node(node[0]);



#endif